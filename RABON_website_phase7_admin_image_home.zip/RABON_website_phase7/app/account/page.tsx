import AuthBox from "../auth-box";
export default function Account(){return <main className="page"><section className="brand"><img src="/rabon-logo.png"/><h1>Welcome to RABON</h1><p>Login or create your customer account.</p></section><section className="panel"><AuthBox/></section></main>}
