"use client";
import {useEffect,useState} from "react";import {useRouter} from "next/navigation";
export default function Cart(){const router=useRouter();const [items,setItems]=useState<any[]>([]);useEffect(()=>setItems(JSON.parse(localStorage.getItem("rabon_cart")||"[]")),[]);
function save(x:any[]){setItems(x);localStorage.setItem("rabon_cart",JSON.stringify(x))}
function qty(id:string,n:number){save(items.map(x=>x.id===id?{...x,qty:Math.max(1,x.qty+n)}:x))}
function remove(id:string){save(items.filter(x=>x.id!==id))}
const total=items.reduce((s,x)=>s+x.price*x.qty,0);
return <main className="cart-page"><header><a href="/store"><img src="/rabon-logo.png"/></a><a href="/store">← Continue Shopping</a></header><section className="cart-box"><h1>Your Cart</h1>{!items.length?<p>Cart খালি। <a href="/store"><u>Products দেখুন</u></a></p>:<>{items.map(x=><div className="cart-item" key={x.id}><div><b>{x.name}</b><small>৳{x.price} × {x.qty}</small></div><div><button onClick={()=>qty(x.id,-1)}>−</button><span>{x.qty}</span><button onClick={()=>qty(x.id,1)}>+</button><button onClick={()=>remove(x.id)}>Remove</button></div></div>)}<div className="cart-total"><b>Total: ৳{total}</b><button className="primary" onClick={()=>router.push("/checkout")}>Proceed to Checkout</button></div></>}</section></main>}
