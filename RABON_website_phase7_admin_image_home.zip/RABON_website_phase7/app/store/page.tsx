"use client";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";

type Product={id:string;name_bn:string;name_en:string;price:number;compare_price:number|null;stock:number;is_trending:boolean;category_id:string|null;product_images?:{image_url:string;sort_order:number}[]};
export default function Store(){
 const [products,setProducts]=useState<Product[]>([]),[cats,setCats]=useState<any[]>([]),[cat,setCat]=useState(""),[q,setQ]=useState(""),[cart,setCart]=useState<any[]>([]);
 useEffect(()=>{setCart(JSON.parse(localStorage.getItem("rabon_cart")||"[]"));(async()=>{const [{data:p},{data:c}]=await Promise.all([supabase.from("products").select("*,product_images(image_url,sort_order)").eq("is_active",true).order("created_at",{ascending:false}),supabase.from("categories").select("*").eq("is_active",true).order("name_en")]);setProducts(p||[]);setCats(c||[])})()},[]);
 function add(p:Product){if(p.stock<1)return;const next=[...cart];const x=next.find(i=>i.id===p.id);if(x)x.qty=Math.min(x.qty+1,p.stock);else next.push({id:p.id,name:p.name_en,price:p.price,qty:1});setCart(next);localStorage.setItem("rabon_cart",JSON.stringify(next));}
 const filtered=products.filter(p=>(!cat||p.category_id===cat)&&(!q||p.name_en.toLowerCase().includes(q.toLowerCase())||p.name_bn.includes(q)));
 const count=cart.reduce((s,x)=>s+x.qty,0);
 return <main><header className="store-head"><a href="/"><img src="/rabon-logo.png"/></a><input value={q} onChange={e=>setQ(e.target.value)} placeholder="পণ্য খুঁজুন / Search..."/><div className="store-actions"><a href="/account">👤 Account</a><a className="cart-link" href="/cart">🛒 Cart ({count})</a></div></header>
 <section className="store-wrap"><div className="category-bar"><button className={!cat?"selected":""} onClick={()=>setCat("")}>All</button>{cats.map(c=><button key={c.id} className={cat===c.id?"selected":""} onClick={()=>setCat(c.id)}>{c.name_en}</button>)}</div>
 <div className="store-grid">{filtered.map(p=><article className="store-product" key={p.id}><div className="store-img">{p.product_images?.[0]?.image_url?<img src={p.product_images[0].image_url}/>:<span>🛍️</span>}</div><div className="store-body"><small>{p.is_trending?"🔥 Trending":""}</small><h3>{p.name_en}</h3><p>{p.name_bn}</p><strong>৳{p.price}</strong>{p.compare_price&&<del>৳{p.compare_price}</del>}<button onClick={()=>add(p)} disabled={p.stock<1}>{p.stock<1?"Out of stock":"Add to Cart"}</button></div></article>)}</div>{!filtered.length&&<div className="empty">কোনো product পাওয়া যায়নি।</div>}</section></main>
}
