 "use client";
import { useEffect, useState } from "react";
import { supabase } from "../../../lib/supabase";
import { useRouter } from "next/navigation";

type Product={id?:string;name_bn:string;name_en:string;slug:string;price:number;compare_price:number|null;stock:number;category_id:string|null;product_type:"reselling"|"affiliate";fulfillment_type:"rabon_delivery"|"supplier_direct";affiliate_url:string;is_trending:boolean;is_active:boolean};
const blank:Product={name_bn:"",name_en:"",slug:"",price:0,compare_price:null,stock:0,category_id:null,product_type:"reselling",fulfillment_type:"supplier_direct",affiliate_url:"",is_trending:false,is_active:true};

export default function Products(){
 const router=useRouter(); const [products,setProducts]=useState<any[]>([]),[cats,setCats]=useState<any[]>([]);
 const [form,setForm]=useState<Product>(blank),[image,setImage]=useState<File|null>(null),[preview,setPreview]=useState(""),[editing,setEditing]=useState(false),[msg,setMsg]=useState(""),[busy,setBusy]=useState(false);
 const load=async()=>{const {data:u}=await supabase.auth.getUser();if(!u.user)return router.replace("/");const {data:p}=await supabase.from("profiles").select("role").eq("id",u.user.id).single();if(p?.role!=="admin")return router.replace("/dashboard");const [{data:ps},{data:cs}]=await Promise.all([supabase.from("products").select("*,product_images(image_url,sort_order)").order("created_at",{ascending:false}),supabase.from("categories").select("*").eq("is_active",true).order("name_en")]);setProducts(ps||[]);setCats(cs||[])};
 useEffect(()=>{load()},[]);
 const set=(k:string,v:any)=>setForm(x=>({...x,[k]:v}));
 const choose=(f:File|null)=>{setImage(f);if(f)setPreview(URL.createObjectURL(f));else setPreview("")};
 const save=async(e:any)=>{e.preventDefault();setBusy(true);setMsg("");try{
   const payload={...form,price:Number(form.price),compare_price:form.compare_price===null||form.compare_price===""?null:Number(form.compare_price),stock:Number(form.stock)};
   let productId=form.id;
   if(editing&&productId){const {error}=await supabase.from("products").update(payload).eq("id",productId);if(error)throw error}
   else {const {data,error}=await supabase.from("products").insert(payload).select("id").single();if(error)throw error;productId=data.id}
   if(image&&productId){
     const ext=image.name.split(".").pop()?.toLowerCase()||"jpg";
     const path=`${productId}/${Date.now()}.${ext}`;
     const up=await supabase.storage.from("product-images").upload(path,image,{upsert:true,contentType:image.type});
     if(up.error)throw up.error;
     const {data:pub}=supabase.storage.from("product-images").getPublicUrl(path);
     const {error:ie}=await supabase.from("product_images").insert({product_id:productId,image_url:pub.publicUrl,sort_order:0});
     if(ie)throw ie;
   }
   setMsg(editing?"Product updated successfully.":"Product added successfully.");setForm(blank);setImage(null);setPreview("");setEditing(false);load();
 }catch(err:any){setMsg(err.message||"Something went wrong")}finally{setBusy(false)}};
 const edit=(p:any)=>{setForm({...p});setEditing(true);setImage(null);setPreview(p.product_images?.[0]?.image_url||"");window.scrollTo({top:0,behavior:"smooth"})};
 const remove=async(id:string)=>{if(!confirm("এই product delete করবেন?"))return;const {error}=await supabase.from("products").delete().eq("id",id);if(error)setMsg(error.message);else load()};
 return <main className="dashboard"><header><img src="/rabon-logo.png"/><div><button onClick={()=>router.push("/admin")}>Dashboard</button> <button onClick={()=>router.push("/store")}>Store</button></div></header>
 <section className="dash"><h1>{editing?"Edit Product":"Add Product"}</h1>
 <form className="product-form" onSubmit={save}>
  <label>Product Image</label><input type="file" accept="image/*" onChange={e=>choose(e.target.files?.[0]||null)}/>
  {preview&&<img className="image-preview" src={preview} alt="preview"/>}
  <label>Name (English)</label><input required value={form.name_en} onChange={e=>set("name_en",e.target.value)}/>
  <label>নাম (বাংলা)</label><input required value={form.name_bn} onChange={e=>set("name_bn",e.target.value)}/>
  <label>Slug</label><input required value={form.slug} onChange={e=>set("slug",e.target.value.toLowerCase().replace(/\s+/g,"-"))}/>
  <div className="two"><div><label>Price (৳)</label><input required type="number" min="0" value={form.price} onChange={e=>set("price",e.target.value)}/></div><div><label>Old Price</label><input type="number" min="0" value={form.compare_price??""} onChange={e=>set("compare_price",e.target.value)}/></div></div>
  <div className="two"><div><label>Stock</label><input required type="number" min="0" value={form.stock} onChange={e=>set("stock",e.target.value)}/></div><div><label>Category</label><select value={form.category_id||""} onChange={e=>set("category_id",e.target.value||null)}><option value="">Select</option>{cats.map(c=><option key={c.id} value={c.id}>{c.name_en}</option>)}</select></div></div>
  <div className="two"><div><label>Type</label><select value={form.product_type} onChange={e=>set("product_type",e.target.value)}><option value="reselling">Reselling</option><option value="affiliate">Affiliate</option></select></div><div><label>Fulfillment</label><select value={form.fulfillment_type} onChange={e=>set("fulfillment_type",e.target.value)}><option value="supplier_direct">Supplier sends to customer</option><option value="rabon_delivery">RABON delivery</option></select></div></div>
  {form.product_type==="affiliate"&&<><label>Affiliate URL</label><input type="url" value={form.affiliate_url||""} onChange={e=>set("affiliate_url",e.target.value)}/></>}
  <label className="check"><input type="checkbox" checked={form.is_trending} onChange={e=>set("is_trending",e.target.checked)}/> Trending product</label>
  <label className="check"><input type="checkbox" checked={form.is_active} onChange={e=>set("is_active",e.target.checked)}/> Active</label>
  <button className="primary" disabled={busy}>{busy?"Saving...":editing?"Update Product":"Add Product"}</button>
  {editing&&<button type="button" className="secondary" onClick={()=>{setForm(blank);setEditing(false);setImage(null);setPreview("")}}>Cancel</button>}
 </form>{msg&&<div className="msg">{msg}</div>}</section>
 <section className="dash"><h2>Products ({products.length})</h2><div className="tablewrap"><table><thead><tr><th>Image</th><th>Product</th><th>Price</th><th>Stock</th><th>Action</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td>{p.product_images?.[0]?.image_url?<img className="thumb" src={p.product_images[0].image_url}/>:<span>—</span>}</td><td>{p.name_en}<br/><small>{p.name_bn}</small></td><td>৳{p.price}</td><td>{p.stock}</td><td><button onClick={()=>edit(p)}>Edit</button> <button onClick={()=>remove(p.id)}>Delete</button></td></tr>)}</tbody></table></div></section>
 </main>
}
