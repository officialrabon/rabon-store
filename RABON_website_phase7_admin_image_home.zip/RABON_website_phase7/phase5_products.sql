
-- RABON Phase 5: product/category management and admin RLS
-- Run after Phase 3 schema + Phase 4 auth trigger.

-- Admin helper. This reads the user's profile role without exposing it to clients.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- Categories: admins can manage; public can read active ones.
create policy "Admins manage categories"
on public.categories for all
using (public.is_admin())
with check (public.is_admin());

-- Products: admins can manage; public can read active products.
create policy "Admins manage products"
on public.products for all
using (public.is_admin())
with check (public.is_admin());

-- Product images: admins can manage.
create policy "Admins manage product images"
on public.product_images for all
using (public.is_admin())
with check (public.is_admin());

-- Useful starter categories.
insert into public.categories (name_bn, name_en, slug)
values
('ফ্যাশন','Fashion','fashion'),
('ইলেকট্রনিক্স','Electronics','electronics'),
('বিউটি','Beauty','beauty'),
('হোম ও কিচেন','Home & Kitchen','home-kitchen'),
('গ্যাজেটস','Gadgets','gadgets'),
('ট্রেন্ডিং','Trending','trending')
on conflict (slug) do nothing;
